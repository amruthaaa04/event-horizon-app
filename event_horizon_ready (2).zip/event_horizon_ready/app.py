﻿# ---------------------------------------------
# Event Horizon - Fixed Flask Application (updated)
# ---------------------------------------------
from flask import (
    Flask, render_template, request, redirect,
    url_for, flash, send_from_directory, session
)
from flask_sqlalchemy import SQLAlchemy
from flask_login import (
    LoginManager, UserMixin, login_user, logout_user,
    current_user, login_required
)
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, timezone, timedelta
import os

# -------------------------------------------------
# APP SETUP
# -------------------------------------------------
app = Flask(__name__)
app.config["SECRET_KEY"] = "dev-secret"
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///app.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# optional cookie tweaks to help session persistence across browsers
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
app.config["SESSION_COOKIE_HTTPONLY"] = True

db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = "login"

UPLOAD_FOLDER = os.path.join(app.root_path, "static", "uploads")
os.makedirs(UPLOAD_FOLDER, exist_ok=True)


# -------------------------------------------------
# MODELS
# -------------------------------------------------
class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    # keep the column as you had it
    full_name = db.Column(db.String(150))
    email = db.Column(db.String(200), unique=True, nullable=False)
    password_hash = db.Column(db.String(200), nullable=False)
    is_admin = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.String(50))

    def check_password(self, pw):
        return check_password_hash(self.password_hash, pw)

    @property
    def display_name(self):
        """
        Safe display name for templates. Prefer full_name, fall back to email local-part.
        Templates can use `current_user.display_name` if preferred; `current_user.full_name`
        will still return the DB column value.
        """
        name = (self.full_name or "").strip()
        if name:
            return name
        # fallback to the part before @ in email
        if self.email:
            return self.email.split("@", 1)[0]
        return "User"


class Event(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200))
    description = db.Column(db.Text)
    venue = db.Column(db.String(200))
    start_time = db.Column(db.String(50))
    end_time = db.Column(db.String(50))
    capacity = db.Column(db.Integer, default=60)
    image_filename = db.Column(db.String(200))
    created_at = db.Column(db.String(50))

    # who booked it
    user_id = db.Column(db.Integer)


# -------------------------------------------------
# LOGIN LOADER
# -------------------------------------------------
@login_manager.user_loader
def load_user(user_id):
    try:
        return User.query.get(int(user_id))
    except Exception:
        return None


# -------------------------------------------------
# HELPERS
# -------------------------------------------------
def nice_dt(iso_str):
    if not iso_str:
        return "TBA"
    try:
        # keep timezone-safe parsing simple
        dt = datetime.fromisoformat(iso_str.split("+")[0])
        return dt.strftime("%b %d, %Y %I:%M %p")
    except Exception:
        return iso_str


app.jinja_env.filters["nice_dt"] = nice_dt


# -------------------------------------------------
# BASIC ROUTES
# -------------------------------------------------
@app.route("/")
def index():
    events = Event.query.order_by(Event.id).all()
    return render_template("index.html", events=events)


@app.route("/uploads/<path:filename>")
def uploads(filename):
    return send_from_directory(UPLOAD_FOLDER, filename)


@app.route("/event/<int:event_id>")
def event_detail(event_id):
    event = Event.query.get_or_404(event_id)
    return render_template("event_detail.html", event=event)


# -------------------------------------------------
# AUTH
# -------------------------------------------------
@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        full_name = (request.form.get("full_name") or "").strip()
        email = (request.form.get("email") or "").strip().lower()
        password = request.form.get("password") or ""

        if not email or not password:
            flash("Email and password are required.", "warning")
            return redirect(url_for("register"))

        if User.query.filter_by(email=email).first():
            flash("Email already exists", "warning")
            return redirect(url_for("login"))

        u = User(
            full_name=full_name,
            email=email,
            password_hash=generate_password_hash(password),
            created_at=datetime.now(timezone.utc).isoformat()
        )
        db.session.add(u)
        db.session.commit()

        flash("Registration successful! Please login.", "success")
        return redirect(url_for("login"))

    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = (request.form.get("email") or "").strip().lower()
        password = request.form.get("password") or ""

        user = User.query.filter_by(email=email).first()
        if not user or not user.check_password(password):
            flash("Invalid credentials", "danger")
            return redirect(url_for("login"))

        # remember=True helps session persistence in some browsers/environments
        login_user(user, remember=True)

        # store a safe display name in session as an extra fallback (optional)
        session["display_name"] = user.full_name or user.email.split("@", 1)[0]

        return redirect(url_for("dashboard"))

    return render_template("login.html")


@app.route("/logout")
@login_required
def logout():
    logout_user()
    session.pop("display_name", None)
    flash("You have logged out.", "info")
    return redirect(url_for("index"))


# -------------------------------------------------
# DASHBOARD
# -------------------------------------------------
@app.route("/dashboard")
@login_required
def dashboard():
    if current_user.is_admin:
        events = Event.query.order_by(Event.id).all()
        users = User.query.order_by(User.id).all()
        return render_template("admin_dashboard.html", events=events, users=users)

    # normal user â†’ show only booked event
    events = Event.query.filter_by(user_id=current_user.id).all()
    return render_template("dashboard.html", events=events)


# -------------------------------------------------
# BOOK EVENT
# -------------------------------------------------
@app.route("/book/<int:event_id>")
@login_required
def book(event_id):
    event = Event.query.get_or_404(event_id)
    event.user_id = current_user.id
    db.session.commit()

    flash("Event booked!", "success")
    return redirect(url_for("dashboard"))


# -------------------------------------------------
# ADMIN â€“ CREATE EVENT
# -------------------------------------------------
@app.route("/admin/event/create", methods=["GET", "POST"])
@login_required
def admin_create_event():
    if not current_user.is_admin:
        return redirect(url_for("dashboard"))

    if request.method == "POST":
        ev = Event(
            title=request.form.get("title"),
            description=request.form.get("description"),
            venue=request.form.get("venue"),
            start_time=request.form.get("start_time"),
            end_time=request.form.get("end_time"),
            image_filename=request.form.get("image_filename"),
            created_at=datetime.now(timezone.utc).isoformat()
        )
        db.session.add(ev)
        db.session.commit()
        flash("Event created!", "success")
        return redirect(url_for("dashboard"))

    return render_template("admin_create_event.html")


# -------------------------------------------------
# ADMIN â€“ EDIT EVENT
# -------------------------------------------------
@app.route("/admin/event/<int:event_id>/edit", methods=["GET", "POST"])
@login_required
def admin_edit_event(event_id):
    if not current_user.is_admin:
        return redirect(url_for("dashboard"))

    ev = Event.query.get_or_404(event_id)

    if request.method == "POST":
        ev.title = request.form.get("title")
        ev.description = request.form.get("description")
        ev.venue = request.form.get("venue")
        ev.start_time = request.form.get("start_time")
        ev.end_time = request.form.get("end_time")
        ev.image_filename = request.form.get("image_filename")

        db.session.commit()
        flash("Event updated!", "success")
        return redirect(url_for("dashboard"))

    return render_template("admin_edit_event.html", event=ev)


# -------------------------------------------------
# ADMIN â€“ DELETE EVENT
# -------------------------------------------------
@app.route("/admin/event/<int:event_id>/delete")
@login_required
def admin_delete_event(event_id):
    if not current_user.is_admin:
        return redirect(url_for("dashboard"))

    ev = Event.query.get_or_404(event_id)
    db.session.delete(ev)
    db.session.commit()

    flash("Event deleted.", "info")
    return redirect(url_for("dashboard"))


# -------------------------------------------------
# AUTO-SEED
# -------------------------------------------------
def seed():
    db.create_all()

    admin = User.query.filter_by(email="admin@eventhorizon.com").first()
    if not admin:
        admin = User(
            full_name="Admin",
            email="admin@eventhorizon.com",
            password_hash=generate_password_hash("Admin@123"),
            is_admin=True,
            created_at=datetime.now(timezone.utc).isoformat()
        )
        db.session.add(admin)
        db.session.commit()

    # Add sample events if none exist
    if Event.query.count() == 0:
        samples = [
            ("Coding Workshop", "Hands-on coding workshop", "Lab A", 2, "event_1.jpg"),
            ("Music Day", "Live music performances", "Auditorium", 4, "event_2.jpg"),
            ("Hackathon", "24-hour challenge", "Main Hall", 6, "event_3.jpg"),
            ("Robotics Championship", "Robot battles", "Sports Complex", 8, "event_4.jpg")
        ]

        for title, desc, venue, offset, img in samples:
            ev = Event(
                title=title,
                description=desc,
                venue=venue,
                start_time=(datetime.now(timezone.utc) + timedelta(days=offset)).isoformat(),
                end_time=(datetime.now(timezone.utc) + timedelta(days=offset, hours=4)).isoformat(),
                image_filename=img,
                created_at=datetime.now(timezone.utc).isoformat()
            )
            db.session.add(ev)

        db.session.commit()


with app.app_context():
    seed()


# -------------------------------------------------
# RUN APP
# -------------------------------------------------
if __name__ == "__main__":
    app.run(debug=True)


# -----------------------------
# BOOKINGS (for seat selection)
# -----------------------------
class Booking(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    event_id = db.Column(db.Integer, db.ForeignKey("event.id"), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    seat = db.Column(db.String(10), nullable=True)  # e.g. "A5"
    created_at = db.Column(db.String(50))

    event = db.relationship("Event", backref=db.backref("bookings", lazy="dynamic"))
    user = db.relationship("User", backref=db.backref("bookings", lazy="dynamic"))


# -----------------------------
# ADMIN — BOOKINGS VIEW
# -----------------------------
@app.route("/admin/bookings")
@login_required
def admin_bookings():
    # admin-only
    if not current_user.is_admin:
        return redirect(url_for("dashboard"))

    # Prefer Booking model if present
    try:
        bookings = Booking.query.order_by(Booking.id.desc()).all()
        return render_template("admin_bookings.html", bookings=bookings, fallback=False)
    except Exception:
        # Fallback: use Event.user_id if Booking model missing
        rows = []
        evs = Event.query.filter(Event.user_id != None).order_by(Event.id.desc()).all()
        for ev in evs:
            u = User.query.get(ev.user_id) if ev.user_id else None
            rows.append({
                "id": None,
                "event": ev,
                "user": u,
                "seat": getattr(ev, "seat", None),
                "created_at": ev.created_at
            })
        return render_template("admin_bookings.html", bookings=rows, fallback=True)


# -----------------------------
# USER — My Bookings & Cancel
# -----------------------------
@app.route("/bookings")
@login_required
def my_bookings():
    """
    Show the current user's bookings.
    If Booking model exists, use it; otherwise fallback to Event.user_id.
    """
    try:
        # Prefer Booking model (if present)
        bookings = Booking.query.filter_by(user_id=current_user.id).order_by(Booking.id.desc()).all()
        return render_template("my_bookings.html", bookings=bookings, fallback=False)
    except Exception:
        # Fallback — events with user_id set to current_user.id
        rows = []
        evs = Event.query.filter_by(user_id=current_user.id).order_by(Event.id.desc()).all()
        for ev in evs:
            rows.append({"event": ev, "created_at": ev.created_at, "booking_id": None})
        return render_template("my_bookings.html", bookings=rows, fallback=True)

@app.route("/booking/<int:booking_id>/cancel", methods=["POST"])
@login_required
def cancel_booking(booking_id):
    """
    Cancel a booking by booking.id (Booking model). Only the owner or admin can cancel.
    """
    try:
        b = Booking.query.get_or_404(booking_id)
        if b.user_id != current_user.id and not current_user.is_admin:
            flash("You are not authorized to cancel this booking.", "danger")
            return redirect(url_for("my_bookings"))
        # delete booking
        db.session.delete(b)
        db.session.commit()
        flash("Your booking has been cancelled.", "success")
        return redirect(url_for("my_bookings"))
    except Exception:
        flash("Unable to cancel booking (Booking model not found).", "warning")
        return redirect(url_for("my_bookings"))

@app.route("/booking/event/<int:event_id>/cancel", methods=["POST"])
@login_required
def cancel_booking_event(event_id):
    """
    Fallback cancel for simple Event.user_id booking: unassign the event.user_id if it belongs to the current user.
    """
    ev = Event.query.get_or_404(event_id)
    if ev.user_id != current_user.id and not current_user.is_admin:
        flash("You are not authorized to cancel this booking.", "danger")
        return redirect(url_for("my_bookings"))
    ev.user_id = None
    db.session.commit()
    flash("Your booking has been cancelled.", "success")
    return redirect(url_for("my_bookings"))


