# app.py
import os
from datetime import datetime, timezone
from flask import Flask, render_template, request, redirect, url_for, flash, abort
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, login_user, logout_user, login_required, current_user, UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

# ---------- App config ----------
app = Flask(__name__, template_folder="templates")
app.config['SECRET_KEY'] = os.environ.get("FH_SECRET_KEY", "dev-secret-key")
# Uses the same DB URI you've been using
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///app.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
# near top of app.py, after `app = Flask(...)` and imports
from datetime import datetime

@app.context_processor
def inject_now():
    # return a callable so templates can use `now()` (e.g. {{ now().year }})
    return {'now': datetime.utcnow}


# ---------- Models ----------
class User(UserMixin, db.Model):
    __tablename__ = 'user'
    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String, nullable=True)
    email = db.Column(db.String, unique=True, nullable=False)
    password_hash = db.Column(db.String, nullable=False)
    role = db.Column(db.String, default='registrant')
    created_at = db.Column(db.String)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class Event(db.Model):
    __tablename__ = 'event'
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String)
    description = db.Column(db.Text)
    venue = db.Column(db.String)
    start_time = db.Column(db.String)
    end_time = db.Column(db.String)
    capacity = db.Column(db.Integer, default=60)
    image_filename = db.Column(db.String)
    created_at = db.Column(db.String)

class Seat(db.Model):
    __tablename__ = 'seat'
    id = db.Column(db.Integer, primary_key=True)
    event_id = db.Column(db.Integer, db.ForeignKey('event.id'))
    row = db.Column(db.String)
    number = db.Column(db.Integer)
    is_booked = db.Column(db.Integer, default=0)

class Booking(db.Model):
    __tablename__ = 'booking'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    event_id = db.Column(db.Integer, db.ForeignKey('event.id'))
    seat_id = db.Column(db.Integer, db.ForeignKey('seat.id'))
    booked_at = db.Column(db.String)

# ---------- Login manager ----------
login_manager = LoginManager()
login_manager.login_view = 'login'
login_manager.init_app(app)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# ---------- Routes ----------
@app.route('/')
def index():
    # Show upcoming events on the home page
    events = Event.query.order_by(Event.id).all()
    return render_template('index.html', events=events)

@app.route('/event/<int:event_id>')
def view_event(event_id):
    event = Event.query.get_or_404(event_id)
    return render_template('view_event.html', event=event)

@app.route('/dashboard')
@login_required
def dashboard():
    # IMPORTANT: this is the updated view you asked for.
    # It loads all events and sends them to dashboard.html
    events = Event.query.order_by(Event.id).all()
    return render_template('dashboard.html', events=events)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = (request.form.get('email') or "").strip().lower()
        password = request.form.get('password') or ""
        user = User.query.filter_by(email=email).first()
        if user and user.check_password(password):
            login_user(user)
            flash('Logged in successfully.', 'success')
            next_page = request.args.get('next') or url_for('dashboard')
            return redirect(next_page)
        flash('Invalid credentials.', 'danger')
        return redirect(url_for('login'))

    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Logged out.', 'info')
    return redirect(url_for('index'))
@app.route('/register', methods=['GET', 'POST'])
def register():
    # simple registration handler: creates a user and logs them in
    if request.method == 'POST':
        full_name = (request.form.get('full_name') or "").strip()
        email = (request.form.get('email') or "").strip().lower()
        password = request.form.get('password') or ""

        if not email or not password:
            flash('Email and password are required.', 'warning')
            return redirect(url_for('register'))

        existing = User.query.filter_by(email=email).first()
        if existing:
            flash('An account with that email already exists. Please log in.', 'warning')
            return redirect(url_for('login'))

        # create user
        now = datetime.now(timezone.utc).isoformat()
        user = User(full_name=full_name, email=email, role='registrant', created_at=now)
        user.set_password(password)
        db.session.add(user)
        db.session.commit()

        # auto-login after registration
        login_user(user)
        flash('Registration successful. You are now logged in.', 'success')
        return redirect(url_for('dashboard'))

    # GET -> render form
    return render_template('register.html')


# ---------- Utility / dev helpers ----------
@app.cli.command('create-tables')
def create_tables():
    """CLI helper: flask create-tables"""
    db.create_all()
    print("db.create_all() completed")

# Safe helper to seed an admin user if missing (non-destructive)
def ensure_admin():
    admin_email = "admin@eventhorizon.com"
    if not User.query.filter_by(email=admin_email).first():
        now = datetime.now(timezone.utc).isoformat()
        admin = User(full_name="Administrator", email=admin_email, role="admin", created_at=now)
        admin.set_password("Admin@123")
        db.session.add(admin)
        db.session.commit()
        print("Admin user created:", admin_email)

# ---------- App start ----------
if __name__ == "__main__":
    # create tables and seed admin inside the app context
    with app.app_context():
        db.create_all()
        try:
            ensure_admin()
        except Exception:
            pass

    app.run(debug=True)
#   - - - -   u p l o a d s   r o u t e   ( a d d e d   a u t o m a t i c a l l y )   - - - - 
 f r o m   f l a s k   i m p o r t   s e n d _ f r o m _ d i r e c t o r y 
 
 @ a p p . r o u t e ( ' / u p l o a d s / < p a t h : f i l e n a m e > ' ) 
 d e f   u p l o a d e d _ f i l e ( f i l e n a m e ) : 
         u p l o a d s _ d i r   =   o s . p a t h . j o i n ( a p p . r o o t _ p a t h ,   ' s t a t i c ' ,   ' u p l o a d s ' ) 
         r e t u r n   s e n d _ f r o m _ d i r e c t o r y ( u p l o a d s _ d i r ,   f i l e n a m e ) 
 #   - - - -   e n d   u p l o a d s   r o u t e   - - - -  
 